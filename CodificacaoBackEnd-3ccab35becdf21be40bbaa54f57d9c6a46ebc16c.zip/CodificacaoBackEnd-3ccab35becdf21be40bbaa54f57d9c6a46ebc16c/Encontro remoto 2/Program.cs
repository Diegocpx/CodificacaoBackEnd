﻿using Encontro_remoto_2.Classes;

PessoaFisica novaPF = new PessoaFisica();

novaPF.nome = "Diego";
novaPF.cpf = "12345678910";

Console.WriteLine($"Nome: {novaPF.nome} - CPF: {novaPF.cpf}");