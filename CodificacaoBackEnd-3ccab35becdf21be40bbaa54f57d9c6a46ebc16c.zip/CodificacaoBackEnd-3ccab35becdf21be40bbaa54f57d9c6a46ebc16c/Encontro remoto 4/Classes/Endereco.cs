namespace Encontro_remoto_2.Classes
{
    public class Endereco
    {
        public string? logradouro { get; set; }

        public int numero { get; set; }

        public string? complemento { get; set; }

        public bool endComercial { get; set; }
    }
}